..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2020 Intel Corporation.

Baseband Device Supported Functionality Matrices
================================================

Supported Feature Flags
-----------------------

.. _table_bbdev_pmd_features:

.. include:: overview_feature_table.txt
